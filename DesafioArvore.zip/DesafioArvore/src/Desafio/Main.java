package Desafio;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArvoreBinaria arvore = new ArvoreBinaria();

		int[] valores = { 50, 30, 20, 40, 70, 60, 80 };
		for (int v : valores) {
			arvore.inserir(v);
		}

		System.out.println("Caminhamento em ordem:");
		arvore.emOrdem();

		System.out.println("Caminhamento pré-ordem:");
		arvore.preOrdem();

		System.out.println("Caminhamento pós-ordem:");
		arvore.posOrdem();
	}
}

package Desafio;

public class Celula {
	
	int valor;
    Celula esquerda, direita;

    public Celula(int valor) {
        this.valor = valor;
        this.esquerda = null;
        this.direita = null;
    }
}
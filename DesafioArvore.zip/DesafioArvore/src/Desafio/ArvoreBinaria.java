package Desafio;

public class ArvoreBinaria {

	private Celula raiz;

	public ArvoreBinaria() {
		raiz = null;
	}

	public void inserir(int valor) {
		raiz = inserirRec(raiz, valor);
	}

	private Celula inserirRec(Celula raiz, int valor) {
		if (raiz == null) {
			return new Celula(valor);
		}

		if (valor < raiz.valor)
			raiz.esquerda = inserirRec(raiz.esquerda, valor);
		else if (valor > raiz.valor)
			raiz.direita = inserirRec(raiz.direita, valor);

		return raiz;
	}

	public void emOrdem() {
		emOrdemRec(raiz);
		System.out.println();
	}

	private void emOrdemRec(Celula raiz) {
		if (raiz != null) {
			emOrdemRec(raiz.esquerda);
			System.out.print(raiz.valor + " ");
			emOrdemRec(raiz.direita);
		}
	}

	public void preOrdem() {
		preOrdemRec(raiz);
		System.out.println();
	}

	private void preOrdemRec(Celula raiz) {
		if (raiz != null) {
			System.out.print(raiz.valor + " ");
			preOrdemRec(raiz.esquerda);
			preOrdemRec(raiz.direita);
		}
	}

	public void posOrdem() {
		posOrdemRec(raiz);
		System.out.println();
	}

	private void posOrdemRec(Celula raiz) {
		if (raiz != null) {
			posOrdemRec(raiz.esquerda);
			posOrdemRec(raiz.direita);
			System.out.print(raiz.valor + " ");
		}
	}
}
